hvasm.exe
High voltage 8-bit flash memory sector protection and unprotection.
----------------------------------------------------------------
Apply EZoFlash+ programmer, crossadapter prot_a1 and 
8-bit flash memory adapter tsop32d, plcc32a1 or dip32a.
Keep package files in the same directory.

20.10.2005, version 0.1

Support flash memory sector protection and chip unprotection:
AMD - AM29F010, AM29F040, 
Fujitsu - 29F040, 
ST Micro - M29F010, M29W010, M29F040, M29W040
Texas Instr. - TMS29F040
All mentioned chips in different versions are verified. 
Details find in chip_test file (v.13)

Software identify more chips with status read , sectors can be protected. 
Unprotection algorythm unknown, follow the software message !!!
Use chip sector protection at your own risk !

EZo
info@ezoflash.com
www.ezoflash.com